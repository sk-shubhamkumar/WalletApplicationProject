package com.pirate.test;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;

import org.junit.Test;

import com.pirate.bean.Customer;
import com.pirate.bean.Transaction;
import com.pirate.bean.Wallet;
import com.pirate.exception.DuplicateIdException;
import com.pirate.exception.InsufficientBalanceException;
import com.pirate.exception.MobileNotFoundException;
import com.pirate.repo.Repository;
import com.pirate.service.IWalletService;
import com.pirate.service.WalletService;

public class ServiceTesting {
	IWalletService service = new WalletService(new Repository());

	
	/************************************
	 * Test case for createCustomer()
	 ************************************/
	
	@Test
	public void createAccountTesting() throws DuplicateIdException {
		Customer customer = new Customer();
		Wallet wallet = new Wallet();
		customer.setName("Nonu");
		customer.setPhone("9808182359");
		customer.setWallet(wallet);
		wallet.setBalance(new BigDecimal(1200));
		assertEquals(customer, service.createCustomer("Nonu", "9808182359", new BigDecimal(1200)));
	}

	
	/************************************
	 * Test case for createCustomer()
	 ************************************/
	
	@Test(expected = DuplicateIdException.class)
	public void duplicateIdTesting() throws DuplicateIdException {
		service.createCustomer("Nonu", "9808182359", new BigDecimal(1200));
		service.createCustomer("Yanshu", "9808182359", new BigDecimal(1000));
	}

	
	/************************************
	 * Test case for showBalance()
	 ************************************/
	
	@Test
	public void showBalanceTesting() throws DuplicateIdException, MobileNotFoundException {
		service.createCustomer("Nonu", "9808182359", new BigDecimal(1200));
		Customer customer = new Customer();
		Wallet wallet = new Wallet();
		customer.setName("Nonu");
		customer.setPhone("9808182359");
		customer.setWallet(wallet);
		wallet.setBalance(new BigDecimal(1200));
		assertEquals(customer, service.showBalance("9808182359"));
	}

	
	/************************************
	 * Test case for showBalance()
	 ************************************/

	@Test(expected = MobileNotFoundException.class)
	public void mobileNotFoundTesting3()
			throws MobileNotFoundException, DuplicateIdException, InsufficientBalanceException {
		service.createCustomer("Nonu", "9808182359", new BigDecimal(1200));
		service.showBalance("8979225022");
	}
	
	
	/************************************
	 * Test case for withdraw()
	 ************************************/
	
	@Test
	public void withrawTesting() throws DuplicateIdException, MobileNotFoundException, InsufficientBalanceException {
		service.createCustomer("Nonu", "9808182359", new BigDecimal(2000));
		Customer cust = service.withdraw("9808182359", new BigDecimal(500));
		Customer customer = new Customer();
		Wallet wallet = new Wallet();
		Transaction transaction = new Transaction();
		transaction.setBalance(new BigDecimal(1500));
		transaction.setIdGenerator();
		transaction.setTransactionType("Debit");
		transaction.setMobile("9808182359");
		customer.setName("Nonu");
		customer.setPhone("9808182359");
		customer.setWallet(wallet);
		customer.setListOfTransaction(cust.getListOfTransaction());
		wallet.setBalance(new BigDecimal(1500));
		assertEquals(customer, cust);
	}
	
	
	/************************************
	 * Test case for withdraw()
	 ************************************/

	@Test(expected = InsufficientBalanceException.class)
	public void insufficientBalanceTesting1()
			throws InsufficientBalanceException, MobileNotFoundException, DuplicateIdException {
		service.createCustomer("Nonu", "9808182359", new BigDecimal(1200));
		service.withdraw("9808182359", new BigDecimal(1700));
	}
	
	
	/************************************
	 * Test case for withdraw()
	 ************************************/

	@Test(expected = MobileNotFoundException.class)
	public void mobileNotFoundTesting1()
			throws MobileNotFoundException, DuplicateIdException, InsufficientBalanceException {
		service.createCustomer("Nonu", "9808182359", new BigDecimal(1200));
		service.withdraw("8979225022", new BigDecimal(1700));
	}


	/************************************
	 * Test case for deposit()
	 ************************************/
	
	@Test
	public void depositTesting() throws DuplicateIdException, MobileNotFoundException {
		service.createCustomer("Nonu", "9808182359", new BigDecimal(2000));
		Customer cust = service.deposit("9808182359", new BigDecimal(2500));
		Customer customer = new Customer();
		Wallet wallet = new Wallet();
		Transaction transaction = new Transaction();
		transaction.setBalance(new BigDecimal(4500));
		transaction.setIdGenerator();
		transaction.setTransactionType("Credit");
		transaction.setMobile("9808182359");
		customer.setName("Nonu");
		customer.setPhone("9808182359");
		customer.setWallet(wallet);
		customer.setListOfTransaction(cust.getListOfTransaction());
		wallet.setBalance(new BigDecimal(4500));
		assertEquals(customer, cust);
	}
	
	
	/************************************
	 * Test case for deposit()
	 ************************************/
	
	@Test(expected = MobileNotFoundException.class)
	public void mobileNotFoundTesting2()
			throws MobileNotFoundException, DuplicateIdException, InsufficientBalanceException {
		service.createCustomer("Nonu", "9808182359", new BigDecimal(1200));
		service.deposit("8979225022", new BigDecimal(1700));
	}
	

	/************************************
	 * Test case for transfer()
	 ************************************/
	
	@Test
	public void transferTesting() throws DuplicateIdException, MobileNotFoundException, InsufficientBalanceException {
		Customer customer1 = service.createCustomer("Nonu", "9808182359", new BigDecimal(1200));
		Customer customer2 = service.createCustomer("Yanshu", "8979225022", new BigDecimal(1500));
		Customer customer[] = service.transfer("9808182359", "8979225022", new BigDecimal(1000));
		Customer customer3 = new Customer();
		Wallet wallet1 = new Wallet();
		Transaction transaction1 = new Transaction();
		transaction1.setBalance(new BigDecimal(200));
		transaction1.setIdGenerator();
		transaction1.setTransactionType("Credit");
		transaction1.setMobile("9808182359");
		customer3.setName("Nonu");
		customer3.setPhone("9808182359");
		customer3.setWallet(wallet1);
		customer3.setListOfTransaction(customer1.getListOfTransaction());
		wallet1.setBalance(new BigDecimal(200));
		Customer customer4 = new Customer();
		Wallet wallet2 = new Wallet();
		Transaction transaction2 = new Transaction();
		transaction2.setBalance(new BigDecimal(2500));
		transaction2.setIdGenerator();
		transaction2.setTransactionType("Credit");
		transaction2.setMobile("9808182359");
		customer4.setName("Yanshu");
		customer4.setPhone("8979225022");
		customer4.setWallet(wallet2);
		customer4.setListOfTransaction(customer2.getListOfTransaction());
		wallet2.setBalance(new BigDecimal(2500));
		assertEquals(customer3, customer[0]);
		assertEquals(customer4, customer[1]);
	}


	/************************************
	 * Test case for transfer()
	 ************************************/
	
	@Test(expected = InsufficientBalanceException.class)
	public void insufficientBalanceTesting2()
			throws DuplicateIdException, MobileNotFoundException, InsufficientBalanceException {
		service.createCustomer("Nonu", "9808182359", new BigDecimal(1200));
		service.createCustomer("Yanshu", "8979225022", new BigDecimal(1500));
		service.transfer("9808182359", "8979225022", new BigDecimal(5000));
	}

	
	/************************************
	 * Test case for transfer()
	 ************************************/
	
	@Test(expected = MobileNotFoundException.class)
	public void mobileNotFoundTesting4()
			throws DuplicateIdException, MobileNotFoundException, InsufficientBalanceException {
		service.createCustomer("Nonu", "9808182353", new BigDecimal(1200));
		service.createCustomer("Yanshu", "8979225022", new BigDecimal(1500));
		service.transfer("9808182308", "8979225022", new BigDecimal(5000));
	}

	
	/************************************
	 * Test case for transfer()
	 ************************************/
	
	@Test(expected = MobileNotFoundException.class)
	public void mobileNotFoundTesting5()
			throws DuplicateIdException, MobileNotFoundException, InsufficientBalanceException {
		service.createCustomer("Nonu", "9808182353", new BigDecimal(1200));
		service.createCustomer("Yanshu", "8979225022", new BigDecimal(1500));
		service.transfer("9808182353", "8979225023", new BigDecimal(5000));
	}
}
