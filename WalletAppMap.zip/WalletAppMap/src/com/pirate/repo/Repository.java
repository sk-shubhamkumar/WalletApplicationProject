package com.pirate.repo;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import com.pirate.bean.Customer;
import com.pirate.bean.Transaction;
import com.pirate.exception.DuplicateIdException;
import com.pirate.exception.MobileNotFoundException;

public class Repository implements IRepository {

	Map<String, Customer> map = new HashMap<>();

	/*********************************************************
	 - Method Name		:	saveCustomer(Customer customer)
	 - Input Parameter	:	Customer customer
	 - Return Type		:	boolean
	 - Throws			:	DuplicateIdException
	 - Author			: 	PIR4T3
	 - Date				:	12-02-2019
	 - Description		:	Save the customer details.
	 *********************************************************/

	@Override
	public boolean saveCustomer(Customer customer) throws DuplicateIdException {
		if (map.containsKey(customer.getPhone())) {
			throw new DuplicateIdException();
		}
		map.put(customer.getPhone(), customer);
		return true;
	}
	
	
	/*********************************************************
	 - Method Name		:	findBalance(String phone)
	 - Input Parameter	:	String phone
	 - Return Type		:	Customer
	 - Throws			:	MobileNotFoundException
	 - Author			: 	PIR4T3
	 - Date				:	12-02-2019
	 - Description		:	Find balance by mobile.
	 *********************************************************/

	@Override
	public Customer findBalance(String phone) throws MobileNotFoundException {
		if (map.containsKey(phone)) {
			return map.get(phone);
		} else {
			throw new MobileNotFoundException();
		}
	}
	
	
	/******************************************************************************
	 - Method Name		:	saveTransaction(String phone, Transaction transaction)
	 - Input Parameter	:	String phone, Transaction transaction
	 - Return Type		:	Customer
	 - Author			: 	PIR4T3
	 - Date				:	12-02-2019
	 - Description		:	Save all the transaction done by customers.
	 *******************************************************************************/

	@Override
	public Customer saveTransaction(String phone, Transaction transaction) {
		if (map.containsKey(transaction.getMobile())) {
			map.get(phone).getListOfTransaction().add(transaction);
			return map.get(phone);
		}
		return null;
	}

}
