package com.pirate.exception;

public class MobileNotFoundException extends Exception {

	@Override
	public String toString() {
		return "Mobile is not exists.";
	}

}
