package com.pirate.service;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import com.pirate.bean.Customer;
import com.pirate.bean.Transaction;
import com.pirate.bean.Wallet;
import com.pirate.exception.DuplicateIdException;
import com.pirate.exception.InsufficientBalanceException;
import com.pirate.exception.MobileNotFoundException;
import com.pirate.repo.IRepository;

public class WalletService implements IWalletService {

	IRepository repo;

	public WalletService(IRepository repo) {
		super();
		this.repo = repo;
	}

	
	/*************************************************************************************
	 - Method Name		:	createCustomer(String name, String phone, BigDecimal balance)
	 - Input Parameter	:	String name, String phone, BigDecimal balance
	 - Return Type		:	Customer
	 - Throws			:	DuplicateIdException
	 - Author			: 	PIR4T3
	 - Date				:	12-02-2019
	 - Description		:	Create new customer.
	 **************************************************************************************/
	
	@Override
	public Customer createCustomer(String name, String phone, BigDecimal balance) throws DuplicateIdException {
		Customer customer = new Customer();
		Wallet wallet = new Wallet();
		customer.setName(name);
		customer.setPhone(phone);
		customer.setWallet(wallet);
		wallet.setBalance(balance);
		if (repo.saveCustomer(customer)) {
			return customer;
		}
		return null;
	}
	
	
	/***********************************************************************
	 - Method Name		:	showBalance(String phone)
	 - Input Parameter	:	String phone
	 - Return Type		:	Customer
	 - Throws			:	MobileNotFoundException
	 - Author			: 	PIR4T3
	 - Date				:	12-02-2019
	 - Description		:	show the current balance in the customer wallet.
	 ************************************************************************/

	@Override
	public Customer showBalance(String phone) throws MobileNotFoundException {
		Customer customer = new Customer();
		return repo.findBalance(phone);
	}

	
	/**********************************************************************
	 - Method Name		:	deposit(String mobile2, BigDecimal balance1)
	 - Input Parameter	:	String mobile2, BigDecimal balance1
	 - Return Type		:	Customer
	 - Throws			:	MobileNotFoundException
	 - Author			: 	PIR4T3
	 - Date				:	12-02-2019
	 - Description		:	Deposit amount to the customer wallet.
	 ***********************************************************************/
	
	@Override
	public Customer deposit(String mobile2, BigDecimal balance1) throws MobileNotFoundException {
		Transaction transaction = new Transaction();
		Customer customer = new Customer();
		customer = repo.findBalance(mobile2);

		customer.getWallet().setBalance(customer.getWallet().getBalance().add(balance1));
		transaction.setIdGenerator();
		transaction.setBalance(customer.getWallet().getBalance());
		transaction.setMobile(mobile2);
		transaction.setTransactionType("Credit");
		repo.saveTransaction(customer.getPhone(), transaction);
		return customer;
	}
	
	
	/*****************************************************************************
	 - Method Name		:	withdraw(String mobile3, BigDecimal balance2)
	 - Input Parameter	:	String mobile3, BigDecimal balance2
	 - Return Type		:	Customer
	 - Throws			:	MobileNotFoundException, InsufficientBalanceException
	 - Author			: 	PIR4T3
	 - Date				:	12-02-2019
	 - Description		:	Withdraw amount from the customer wallet.
	 ******************************************************************************/

	public Customer withdraw(String mobile3, BigDecimal balance2)
			throws MobileNotFoundException, InsufficientBalanceException {
		Customer customer = new Customer();
		Transaction transaction = new Transaction();
		customer = repo.findBalance(mobile3);

		if (balance2.compareTo(customer.getWallet().getBalance()) == 1) {
			throw new InsufficientBalanceException();
		} else {
			customer.getWallet().setBalance(customer.getWallet().getBalance().subtract(balance2));
			transaction.setIdGenerator();
			transaction.setBalance(customer.getWallet().getBalance());
			transaction.setMobile(mobile3);
			transaction.setTransactionType("Debit");
			repo.saveTransaction(customer.getPhone(), transaction);
		}
		return customer;

	}

	
	/***************************************************************************************
	 - Method Name		:	transfer(String mobile4, String mobile5, BigDecimal balance3)
	 - Input Parameter	:	String mobile4, String mobile5, BigDecimal balance3
	 - Return Type		:	Customer[]
	 - Throws			:	MobileNotFoundException, InsufficientBalanceException
	 - Author			: 	PIR4T3
	 - Date				:	12-02-2019
	 - Description		:	Transfer amount to another customer wallet.
	 ****************************************************************************************/
	
	@Override
	public Customer[] transfer(String mobile4, String mobile5, BigDecimal balance3)
			throws MobileNotFoundException, InsufficientBalanceException {
		Customer[] customer = new Customer[2];
		Customer senderCustomer = new Customer();
		Customer receiverCustomer = new Customer();

		Transaction senderTransaction = new Transaction();
		Transaction receiverTransaction = new Transaction();

		senderCustomer = repo.findBalance(mobile4);
		receiverCustomer = repo.findBalance(mobile5);

		if (balance3.compareTo(senderCustomer.getWallet().getBalance()) == 1) {
			throw new InsufficientBalanceException();
		} else {
			senderCustomer.getWallet().setBalance(senderCustomer.getWallet().getBalance().subtract(balance3));
			senderTransaction.setIdGenerator();
			senderTransaction.setBalance(senderCustomer.getWallet().getBalance());
			senderTransaction.setMobile(mobile4);
			senderTransaction.setTransactionType("Transfer to "+receiverCustomer.getPhone());
			repo.saveTransaction(mobile4, senderTransaction);
			customer[0] = senderCustomer;

			receiverCustomer.getWallet().setBalance(receiverCustomer.getWallet().getBalance().add(balance3));
			receiverTransaction.setIdGenerator();
			receiverTransaction.setBalance(receiverCustomer.getWallet().getBalance());
			receiverTransaction.setMobile(mobile5);
			receiverTransaction.setTransactionType("Transfer from "+senderCustomer.getPhone());
			repo.saveTransaction(mobile5, receiverTransaction);
			customer[1] = receiverCustomer;
		}
		return customer;
	}

	
	/********************************************************************************
	 - Method Name		:	showLastTransactions(String mobile6, int noOfTransaction)
	 - Input Parameter	:	String mobile6, int noOfTransaction
	 - Return Type		:	List<Transaction>
	 - Throws			:	MobileNotFoundException
	 - Author			: 	PIR4T3
	 - Date				:	12-02-2019
	 - Description		:	Show all last transaction.
	 *********************************************************************************/
	
	@Override
	public List<Transaction> showLastTransactions(String mobile6, int noOfTransaction) throws MobileNotFoundException {
		List<Transaction> transactionList = new LinkedList<>();
		Customer customer = new Customer();
		customer = repo.findBalance(mobile6);

		List<Transaction> tempList = new LinkedList<>();
		tempList.addAll(customer.getListOfTransaction());

		Collections.reverse(tempList);

		if (noOfTransaction >= tempList.size()) {
			return tempList;
		}

		transactionList.clear();
		for (int i = 0; i < noOfTransaction; i++) {

			transactionList.add(tempList.get(i));
		}
		return transactionList;
	}

}
