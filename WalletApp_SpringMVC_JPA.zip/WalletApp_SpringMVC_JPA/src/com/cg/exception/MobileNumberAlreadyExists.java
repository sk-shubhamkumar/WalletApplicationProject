package com.cg.exception;

public class MobileNumberAlreadyExists extends Exception {

	public MobileNumberAlreadyExists() {
		super();
	}
	
	public MobileNumberAlreadyExists(String message) {
		super();
	}
}

