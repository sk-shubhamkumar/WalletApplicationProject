package com.cg.exception;

public class InsufficientBalanceException extends Exception{

	public InsufficientBalanceException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InsufficientBalanceException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
