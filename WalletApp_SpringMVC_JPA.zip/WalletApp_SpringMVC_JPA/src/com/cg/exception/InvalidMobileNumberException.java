package com.cg.exception;

public class InvalidMobileNumberException extends Exception {

	public InvalidMobileNumberException() {
		super();
	}

	public InvalidMobileNumberException(String message) {
		super(message);
	}
}
