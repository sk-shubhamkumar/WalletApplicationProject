package com.cg.service;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.cg.beans.Customer;
import com.cg.beans.Wallet;
import com.cg.exception.InsufficientBalanceException;
import com.cg.exception.InvalidInputException;
import com.cg.exception.InvalidMobileNumberException;
import com.cg.exception.MobileNumberAlreadyExists;
import com.cg.repo.WalletRepo;

@Service("ser")
@Component(value = "ser")
public class WalletServiceImpl implements WalletService {

	@Autowired
	private WalletRepo repo;

	public WalletServiceImpl() {
		super();
	}

	public WalletServiceImpl(WalletRepo repo) {
		super();
		this.repo = repo;
	}

	public Customer createAccount(Customer customer) throws MobileNumberAlreadyExists {
		Customer result = repo.findOne(customer.getMobileNo());
		if (result != null) {
			throw new MobileNumberAlreadyExists("Mobile Number Already Exists");
		}
		return repo.save(customer);
	}

	public Customer showBalance(String mobileNo) throws InvalidMobileNumberException {

		Customer customer = repo.findOne(mobileNo);
		if(customer == null) {
			throw new InvalidMobileNumberException("Invalid Mobile Number ");
		}
		return customer;
	}

	public Customer fundTransfer(String sourceMobileNo, String targetMobileNo, BigDecimal amount)
			throws InvalidInputException, InsufficientBalanceException, InvalidMobileNumberException {

		Customer customer1 = repo.findOne(sourceMobileNo);
		Customer customer2 = repo.findOne(targetMobileNo);
		if(customer1==null || customer2==null) {
			throw new InvalidMobileNumberException("Invalid Mobile Number");
		}
		else {
			BigDecimal balance1 = customer1.getWallet().getBalance();
			BigDecimal balance2 = customer2.getWallet().getBalance();
			if (balance1.compareTo(amount) >= 0) {
				balance1 = balance1.subtract(amount);
				customer1.setWallet(new Wallet(balance1));
				repo.save(customer1);
				balance2 = balance2.add(amount);
				customer2.setWallet(new Wallet(balance2));
				repo.save(customer2);
			}
			else {
				throw new InsufficientBalanceException("Insufficient Balance");
			}
		}
		return customer1;
	}

	public Customer depositAmount(String mobileNo, BigDecimal amount) throws InvalidInputException, InvalidMobileNumberException {

		Customer customer = repo.findOne(mobileNo);
		if(customer == null) {
			throw new InvalidMobileNumberException("Invalid Mobile Number");
		}
		if(amount.compareTo(new BigDecimal("0"))<=0) {
			throw new InvalidInputException("Amount is not Valid");
		}
		BigDecimal bal = customer.getWallet().getBalance().add(amount);

		customer.setWallet(new Wallet(bal));
		repo.save(customer);

		return customer;
	}

	public Customer withdrawAmount(String mobileNo, BigDecimal amount)
			throws InvalidInputException, InsufficientBalanceException, InvalidMobileNumberException {
		if (amount == null || amount.compareTo(new BigDecimal("0"))<=0)
			throw new InvalidInputException("Amount cannot be null");

		if (mobileNo == null || mobileNo.length()==0)
			throw new InvalidInputException("Source Mobile mobile number cannot be null");

		Customer cust = repo.findOne(mobileNo);
		if (cust == null) {
			throw new InvalidMobileNumberException("Invalid Mobile Number");
		}
		BigDecimal bal = cust.getWallet().getBalance();
		if (bal.compareTo(amount) >= 0) {
			bal = bal.subtract(amount);
			cust.setWallet(new Wallet(bal));
			repo.save(cust);

		} else {
			throw new InsufficientBalanceException("Insufficient balance");
		}
		return cust;
	}

}