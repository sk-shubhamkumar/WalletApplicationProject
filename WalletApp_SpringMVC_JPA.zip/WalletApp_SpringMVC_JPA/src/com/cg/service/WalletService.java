package com.cg.service;
import java.math.BigDecimal;
import java.util.List;

import com.cg.beans.Customer;
import com.cg.exception.InsufficientBalanceException;
import com.cg.exception.InvalidInputException;
import com.cg.exception.InvalidMobileNumberException;
import com.cg.exception.MobileNumberAlreadyExists;

public interface WalletService {
public Customer createAccount(Customer customer) throws MobileNumberAlreadyExists;
public Customer showBalance (String mobileno) throws InvalidMobileNumberException;
public Customer fundTransfer (String sourceMobileNo,String targetMobileNo, BigDecimal amount) throws InvalidInputException, InsufficientBalanceException, InvalidMobileNumberException;
public Customer depositAmount (String mobileNo,BigDecimal amount )throws InvalidInputException, InvalidMobileNumberException;
public Customer withdrawAmount(String mobileNo, BigDecimal amount)throws InvalidInputException, InsufficientBalanceException, InvalidMobileNumberException;
}
