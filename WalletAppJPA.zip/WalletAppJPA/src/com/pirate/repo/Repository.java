package com.pirate.repo;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import javax.persistence.EntityManager;

import com.pirate.bean.Customer;
import com.pirate.bean.Transaction;
import com.pirate.bean.Wallet;
import com.pirate.exception.DuplicateIdException;
import com.pirate.exception.MobileNotFoundException;
import com.pirate.util.JPAUtil;

public class Repository implements IRepository {

	EntityManager em;
	
	public Repository() {
		super();
		em = JPAUtil.getEntityManager();
	}


	/*********************************************************
	 - Method Name		:	saveCustomer(Customer customer)
	 - Input Parameter	:	Customer customer
	 - Return Type		:	boolean
	 - Throws			:	DuplicateIdException
	 - Author			: 	PIR4T3
	 - Date				:	12-02-2019
	 - Description		:	Save the customer details.
	 *********************************************************/

	@Override
	public boolean saveCustomer(Customer customer) {
		Customer cust = new Customer();
		em.getTransaction().begin();
		cust = em.find(Customer.class, customer.getPhone());
		if(cust==null) {
			em.persist(customer);
			em.getTransaction().commit();
			return true;
		}
		return false;

	}
	
	
	/*********************************************************
	 - Method Name		:	findBalance(String phone)
	 - Input Parameter	:	String phone
	 - Return Type		:	Customer
	 - Throws			:	MobileNotFoundException
	 - Author			: 	PIR4T3
	 - Date				:	12-02-2019
	 - Description		:	Find balance by mobile.
	 *********************************************************/

	@Override
	public Customer findBalance(String phone) {
		Customer customer = em.find(Customer.class, phone);
		if(customer!=null) {
			return customer;
		}
		return null;
	}
	
	
	/******************************************************************************
	 - Method Name		:	saveTransaction(String phone, Transaction transaction)
	 - Input Parameter	:	String phone, Transaction transaction
	 - Return Type		:	Customer
	 - Author			: 	PIR4T3
	 - Date				:	12-02-2019
	 - Description		:	Save all the transaction done by customers.
	 *******************************************************************************/

	@Override
	public Customer saveTransaction(String phone, Transaction transaction) {
		em.getTransaction().begin();
		Customer customer = em.find(Customer.class, phone);
		if(customer!=null) {
			Wallet wallet = new Wallet();
			wallet.setBalance(transaction.getBalance());
			customer.setWallet(wallet);
			customer.getListOfTransaction().add(transaction);
			em.persist(transaction);
			em.getTransaction().commit();
			return customer;
		}
		return null;
	}

}
