package com.pirate.main;

import java.math.BigDecimal;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.pirate.bean.Customer;
import com.pirate.bean.Transaction;
import com.pirate.exception.DuplicateIdException;
import com.pirate.exception.InsufficientBalanceException;
import com.pirate.exception.MobileNotFoundException;
import com.pirate.repo.Repository;
import com.pirate.service.IWalletService;
import com.pirate.service.WalletService;

public class Client {

	public static void main(String[] args) {
		IWalletService service = new WalletService(new Repository());

		Scanner scanner = new Scanner(System.in);
		char flag = 'Y';
		System.out.println("\n" + new String(new char[52]).replace("\0", "-"));
		System.out.println(String.format("|%20s%-30s|", "", "WalletApp Menu"));
		System.out.println(new String(new char[52]).replace("\0", "-"));
		System.out.println(String.format("|%15s%-35s|", "", "1. Create Account"));
		System.out.println(String.format("|%15s%-35s|", "", "2. Show Balance"));
		System.out.println(String.format("|%15s%-35s|", "", "3. Deposite"));
		System.out.println(String.format("|%15s%-35s|", "", "4. Withdraw"));
		System.out.println(String.format("|%15s%-35s|", "", "5. Transfer Money"));
		System.out.println(String.format("|%15s%-35s|", "", "6. Show Last transaction"));
		System.out.println(String.format("|%15s%-35s|", "", "7. Show Menu"));
		System.out.println(String.format("|%15s%-35s|", "", "8. Exit"));
		System.out.println(new String(new char[52]).replace("\0", "-"));

		while (flag == 'Y') {
			System.out.print("\nEnter Choice: ");
			int choice = scanner.nextInt();
			scanner.nextLine();
			switch (choice) {
			case 1:
				System.out.println("\nEnter Mobile No: ");
				String mobile = scanner.nextLine();
				if (isMobileValid(mobile)) {
					System.out.println("\nEnter Name: ");
					String name = scanner.nextLine();
					if (isNameValid(name)) {
						BigDecimal balance = new BigDecimal(0);
						Customer customer;
						try {
							customer = service.createCustomer(name, mobile, balance);
							if (customer != null) {
								System.out.println("\nAccount is created.\n");
								System.out.println(new String(new char[40]).replace("\0", "-"));
								System.out.println(String.format("|%12s%-10s  %-9s|", "", "Customer Detail", ""));
								System.out.println(new String(new char[40]).replace("\0", "-"));
								System.out.println(String.format("|%4s%-16s: %-16s|", "", "Name", customer.getName()));
								System.out.println(
										String.format("|%4s%-16s: %-16s|", "", "Mobile No", customer.getPhone()));
								System.out.println(String.format("|%4s%-16s: Rs %-13s|", "", "Current Balance",
										customer.getWallet().getBalance()));
								System.out.println(new String(new char[40]).replace("\0", "-"));
								break;
							}
						} catch (DuplicateIdException e) {
							System.out.println("\n" + new String(new char[42]).replace("\0", "-"));
							System.out.println(String.format("|%14s%-26s|", "", "Error Message"));
							System.out.println(new String(new char[42]).replace("\0", "-"));
							System.out.println(String.format("|%2s%-38s|", "", e));
							System.out.println(new String(new char[42]).replace("\0", "-"));
						}
					} else {
						System.out.println("\n" + new String(new char[42]).replace("\0", "-"));
						System.out.println(String.format("|%14s%-26s|", "", "Error Message"));
						System.out.println(new String(new char[42]).replace("\0", "-"));
						System.out.println(String.format("|%2s%-38s|", "", "Name is not Valid."));
						System.out.println(new String(new char[42]).replace("\0", "-"));

					}
				} else {
					System.out.println("\n" + new String(new char[42]).replace("\0", "-"));
					System.out.println(String.format("|%14s%-26s|", "", "Error Message"));
					System.out.println(new String(new char[42]).replace("\0", "-"));
					System.out.println(String.format("|%2s%-38s|", "", "Mobile No. is not Valid."));
					System.out.println(new String(new char[42]).replace("\0", "-"));
				}
				break;

			case 2:
				System.out.println("\nEnter Mobile No: ");
				String mobile1 = scanner.nextLine();
				if (isMobileValid(mobile1)) {
					Customer customer1;
					try {
						customer1 = service.showBalance(mobile1);
						System.out.println("\n" + new String(new char[40]).replace("\0", "-"));
						System.out.println(String.format("|%12s%-10s  %-9s|", "", "Balance Details", ""));
						System.out.println(new String(new char[40]).replace("\0", "-"));
						System.out.println(String.format("|%4s%-16s: %-16s|", "", "Name", customer1.getName()));
						System.out.println(String.format("|%4s%-16s: Rs %-13s|", "", "Current Balance",
								customer1.getWallet().getBalance()));
						System.out.println(new String(new char[40]).replace("\0", "-"));
					} catch (MobileNotFoundException e) {
						System.out.println("\n" + new String(new char[42]).replace("\0", "-"));
						System.out.println(String.format("|%14s%-26s|", "", "Error Message"));
						System.out.println(new String(new char[42]).replace("\0", "-"));
						System.out.println(String.format("|%2s%-38s|", "", e));
						System.out.println(new String(new char[42]).replace("\0", "-"));
					}
				} else {
					System.out.println("\n" + new String(new char[42]).replace("\0", "-"));
					System.out.println(String.format("|%14s%-26s|", "", "Error Message"));
					System.out.println(new String(new char[42]).replace("\0", "-"));
					System.out.println(String.format("|%2s%-38s|", "", "Mobile No. is not Valid."));
					System.out.println(new String(new char[42]).replace("\0", "-"));
				}
				break;

			case 3:
				System.out.println("\nEnter Mobile No: ");
				String mobile2 = scanner.nextLine();
				if (isMobileValid(mobile2)) {
					System.out.println("\nEnter Money to Deposite: ");
					String balanceStr1 = scanner.nextLine();
					if (isBalanceStrValid(balanceStr1)) {
						BigDecimal balance1 = new BigDecimal(balanceStr1);
						Customer customer2;
						try {
							customer2 = service.deposit(mobile2, balance1);
							System.out.println("\n" + new String(new char[60]).replace("\0", "-"));
							System.out.println(String.format("|%25s%-33s|", "", "Message"));
							System.out.println(new String(new char[60]).replace("\0", "-"));
							System.out.println(String.format("|%2s%-56s|", "",
									"Rs " + balanceStr1 + " is Credited to your Account."));
							System.out.println(String.format("|%2s%-56s|", "",
									"Updated Balance: Rs " + customer2.getWallet().getBalance() + "."));
							System.out.println(new String(new char[60]).replace("\0", "-"));
						} catch (MobileNotFoundException e) {
							System.out.println(new String(new char[42]).replace("\0", "-"));
							System.out.println(String.format("|%14s%-26s|", "", "Error Message"));
							System.out.println(new String(new char[42]).replace("\0", "-"));
							System.out.println(String.format("|%2s%-38s|", "", e));
							System.out.println(new String(new char[42]).replace("\0", "-"));
						}
					}

				} else {
					System.out.println("\n" + new String(new char[42]).replace("\0", "-"));
					System.out.println(String.format("|%14s%-26s|", "", "Error Message"));
					System.out.println(new String(new char[42]).replace("\0", "-"));
					System.out.println(String.format("|%2s%-38s|", "", "Mobile No. is not Valid."));
					System.out.println(new String(new char[42]).replace("\0", "-"));
				}
				break;

			case 4:
				System.out.println("\nEnter Mobile No: ");
				String mobile3 = scanner.nextLine();
				if (isMobileValid(mobile3)) {
					System.out.println("\nEnter Money to Withdraw: ");
					String balanceStr2 = scanner.nextLine();
					if (isBalanceStrValid(balanceStr2)) {
						BigDecimal balance2 = new BigDecimal(balanceStr2);
						Customer customer3;
						try {
							customer3 = service.withdraw(mobile3, balance2);
							System.out.println(new String(new char[60]).replace("\0", "-"));
							System.out.println(String.format("|%25s%-33s|", "", "Message"));
							System.out.println(new String(new char[60]).replace("\0", "-"));
							System.out.println(String.format("|%2s%-56s|", "",
									"Rs " + balanceStr2 + " is Debited from your Account."));
							System.out.println(String.format("|%2s%-56s|", "",
									"Updated Balance: Rs " + customer3.getWallet().getBalance() + "."));
							System.out.println(new String(new char[60]).replace("\0", "-"));
						} catch (MobileNotFoundException | InsufficientBalanceException e) {
							System.out.println(new String(new char[42]).replace("\0", "-"));
							System.out.println(String.format("|%14s%-26s|", "", "Error Message"));
							System.out.println(new String(new char[42]).replace("\0", "-"));
							System.out.println(String.format("|%2s%-38s|", "", e));
							System.out.println(new String(new char[42]).replace("\0", "-"));
						}
					}

				} else {
					System.out.println(new String(new char[42]).replace("\0", "-"));
					System.out.println(String.format("|%14s%-26s|", "", "Error Message"));
					System.out.println(new String(new char[42]).replace("\0", "-"));
					System.out.println(String.format("|%2s%-38s|", "", "Mobile No. is not Valid."));
					System.out.println(new String(new char[42]).replace("\0", "-"));
				}
				break;

			case 5:
				System.out.println("\nEnter Sender Mobile No: ");
				String mobile4 = scanner.nextLine();
				if (isMobileValid(mobile4)) {
					System.out.println("\nEnter Receiver Mobile No:");
					String mobile5 = scanner.nextLine();
					if (isMobileValid(mobile5)) {
						System.out.println("\nEnter Money to Withdraw: ");
						String balanceStr3 = scanner.nextLine();
						if (isBalanceStrValid(balanceStr3)) {
							BigDecimal balance3 = new BigDecimal(balanceStr3);
							Customer[] customer4;
							try {
								customer4 = service.transfer(mobile4, mobile5, balance3);
								System.out.println(new String(new char[60]).replace("\0", "-"));
								System.out.println(String.format("|%25s%-33s|", "", "Message"));
								System.out.println(new String(new char[60]).replace("\0", "-"));
								System.out.println(String.format("|%2s%-56s|", "", "Rs " + balance3
										+ " is transfered to " + customer4[1].getPhone() + " from your Account."));
								System.out.println(String.format("|%2s%-56s|", "",
										"Update Balance: Rs " + customer4[0].getWallet().getBalance() + "."));
								System.out.println(new String(new char[60]).replace("\0", "-"));
							} catch (MobileNotFoundException | InsufficientBalanceException e) {
								System.out.println(new String(new char[42]).replace("\0", "-"));
								System.out.println(String.format("|%14s%-26s|", "", "Error Message"));
								System.out.println(new String(new char[42]).replace("\0", "-"));
								System.out.println(String.format("|%2s%-38s|", "", e));
								System.out.println(new String(new char[42]).replace("\0", "-"));
							}
						}
					} else {
						System.out.println(new String(new char[42]).replace("\0", "-"));
						System.out.println(String.format("|%14s%-26s|", "", "Error Message"));
						System.out.println(new String(new char[42]).replace("\0", "-"));
						System.out.println(String.format("|%2s%-38s|", "", "Receiver Mobile No. is not Valid."));
						System.out.println(new String(new char[42]).replace("\0", "-"));
					}

				} else {
					System.out.println(new String(new char[42]).replace("\0", "-"));
					System.out.println(String.format("|%14s%-26s|", "", "Error Message"));
					System.out.println(new String(new char[42]).replace("\0", "-"));
					System.out.println(String.format("|%2s%-38s|", "", "Sender Mobile No. is not Valid."));
					System.out.println(new String(new char[42]).replace("\0", "-"));
				}
				break;

			case 6:
				System.out.println("\nEnter Mobile No: ");
				String mobile6 = scanner.nextLine();
				BigDecimal tempBal;
				if (isMobileValid(mobile6)) {
					System.out.println("\nNo of Transactions want to show: ");
					int noOfTransaction = scanner.nextInt();
					if (isNoOfTransactionValid(noOfTransaction)) {
						List<Transaction> transactionList;
						try {
							transactionList = service.showLastTransactions(mobile6, noOfTransaction);
							
							System.out.println();
							
							
							System.out.println(new String(new char[70]).replace("\0", "-"));		
							System.out.println(String.format("|%21s%-38s|","","Transaction Details"));
//							System.out.println(String.format("|%2s%-37s%-20s|","", "Name: ","Mob: "));							
							System.out.println(new String(new char[70]).replace("\0", "-"));
							System.out.println(
									String.format("|%15s%30s%10s%12s%2s|", "Trans Id", "Tran Type", "Amount", "Curr Bal", ""));
							System.out.println(new String(new char[70]).replace("\0", "-"));
							for (Transaction tlist : transactionList) {
								System.out.println(String.format("|%15s%30s%10s%12s%2s|", tlist.getId(),
										tlist.getTransactionType(), tlist.getAmount() ,tlist.getBalance(), ""));
							}
							System.out.println(new String(new char[70]).replace("\0", "-"));
						} catch (MobileNotFoundException e) {
							System.out.println(new String(new char[42]).replace("\0", "-"));
							System.out.println(String.format("|%14s%-26s|", "", "Error Message"));
							System.out.println(new String(new char[42]).replace("\0", "-"));
							System.out.println(String.format("|%2s%-38s|", "", e));
							System.out.println(new String(new char[42]).replace("\0", "-"));
						}
					}
				} else {
					System.out.println(new String(new char[42]).replace("\0", "-"));
					System.out.println(String.format("|%14s%-26s|", "", "Error Message"));
					System.out.println(new String(new char[42]).replace("\0", "-"));
					System.out.println(String.format("|%2s%-38s|", "", "Mobile No. is not Valid."));
					System.out.println(new String(new char[42]).replace("\0", "-"));
				}
				break;

			case 7:
				System.out.println("\n" + new String(new char[52]).replace("\0", "-"));
				System.out.println(String.format("|%20s%-30s|", "", "WalletApp Menu"));
				System.out.println(new String(new char[52]).replace("\0", "-"));
				System.out.println(String.format("|%15s%-35s|", "", "1. Create Account"));
				System.out.println(String.format("|%15s%-35s|", "", "2. Show Balance"));
				System.out.println(String.format("|%15s%-35s|", "", "3. Deposite"));
				System.out.println(String.format("|%15s%-35s|", "", "4. Withdraw"));
				System.out.println(String.format("|%15s%-35s|", "", "5. Transfer Money"));
				System.out.println(String.format("|%15s%-35s|", "", "6. Show Last transaction"));
				System.out.println(String.format("|%15s%-35s|", "", "7. Show Menu"));
				System.out.println(String.format("|%15s%-35s|", "", "8. Exit"));
				System.out.println(new String(new char[52]).replace("\0", "-"));
				break;

			case 8:
				flag = 'N';
				break;

			}
		}

	}

	private static boolean isNoOfTransactionValid(int noOfTransaction) {
		String number = "" + noOfTransaction;
		String numPattern = "^\\d*$";
		Pattern pattern = Pattern.compile(numPattern);
		Matcher matcher = pattern.matcher(number);
		return matcher.matches();
	}

	private static boolean isMobileValid(String mobile) {
		String mobilePattern = "^[6-9][0-9]{9}$";
		Pattern pattern = Pattern.compile(mobilePattern);
		Matcher matcher = pattern.matcher(mobile);
		return matcher.matches();
	}

	private static boolean isNameValid(String name) {
		String namePattern = "^[A-Za-z\\s]{3,}$";
		Pattern pattern = Pattern.compile(namePattern);
		Matcher matcher = pattern.matcher(name);
		return matcher.matches();
	}

	private static boolean isBalanceStrValid(String balanceStr) {
		String balancePattern = "^\\d*$";
		Pattern pattern = Pattern.compile(balancePattern);
		Matcher matcher = pattern.matcher(balanceStr);
		return matcher.matches();
	}

}
