package com.pirate.test;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;

import org.junit.Test;

import com.pirate.bean.Customer;
import com.pirate.bean.Transaction;
import com.pirate.bean.Wallet;
import com.pirate.exception.DuplicateIdException;
import com.pirate.exception.InsufficientBalanceException;
import com.pirate.exception.MobileNotFoundException;
import com.pirate.repo.Repository;
import com.pirate.service.IWalletService;
import com.pirate.service.WalletService;

public class ServiceTesting {
	IWalletService service = new WalletService(new Repository());

	
	/************************************
	 * Test case for createCustomer()
	 ************************************/
	
	@Test
	public void createAccountTesting() throws DuplicateIdException {
		Customer customer = new Customer();
		Wallet wallet = new Wallet();
		customer.setName("Nonu");
		customer.setPhone("7599246005");
		customer.setWallet(wallet);
		wallet.setBalance(new BigDecimal(1200));
		assertEquals(customer, service.createCustomer("Nonu", "7599246005", new BigDecimal(1200)));
	}

	
	/************************************
	 * Test case for createCustomer()
	 ************************************/
	
	@Test(expected = DuplicateIdException.class)
	public void duplicateIdTesting() throws DuplicateIdException {
		service.createCustomer("Nonu", "9808182359", new BigDecimal(1200));
		service.createCustomer("Yanshu", "9808182359", new BigDecimal(1000));
	}

	
	/************************************
	 * Test case for showBalance()
	 ************************************/
	
	@Test
	public void showBalanceTesting() throws DuplicateIdException, MobileNotFoundException {
		service.createCustomer("Nonu", "8745859654", new BigDecimal(1200));
		Customer customer = new Customer();
		Wallet wallet = new Wallet();
		customer.setName("Nonu");
		customer.setPhone("8745859654");
		customer.setWallet(wallet);
		wallet.setBalance(new BigDecimal(1200));
		assertEquals(customer, service.showBalance("8745859654"));
	}

	
	/************************************
	 * Test case for showBalance()
	 ************************************/

	@Test(expected = MobileNotFoundException.class)
	public void mobileNotFoundTesting3()
			throws MobileNotFoundException, DuplicateIdException, InsufficientBalanceException {
		service.createCustomer("Nonu", "9808582359", new BigDecimal(1200));
		service.showBalance("8979225022");
	}
	
	
	/************************************
	 * Test case for withdraw()
	 ************************************/
	
	@Test
	public void withrawTesting() throws DuplicateIdException, MobileNotFoundException, InsufficientBalanceException {
		service.createCustomer("Nonu", "9808182459", new BigDecimal(2000));
		Customer cust = service.withdraw("9808182459", new BigDecimal(500));
		Customer customer = new Customer();
		Wallet wallet = new Wallet();
		Transaction transaction = new Transaction();
		transaction.setBalance(new BigDecimal(1500));
		transaction.setTransactionType("Debit");
		transaction.setAmount(new BigDecimal(500));
		transaction.setMobile("9808182459");
		customer.setName("Nonu");
		customer.setPhone("9808182459");
		customer.setWallet(wallet);
		customer.setListOfTransaction(cust.getListOfTransaction());
		wallet.setBalance(new BigDecimal(1500));
		assertEquals(customer, cust);
	}
	
	
	/************************************
	 * Test case for withdraw()
	 ************************************/

	@Test(expected = InsufficientBalanceException.class)
	public void insufficientBalanceTesting1()
			throws InsufficientBalanceException, MobileNotFoundException, DuplicateIdException {
		service.createCustomer("Nonu", "9805182359", new BigDecimal(1200));
		service.withdraw("9805182359", new BigDecimal(1700));
	}
	
	
	/************************************
	 * Test case for withdraw()
	 ************************************/

	@Test(expected = MobileNotFoundException.class)
	public void mobileNotFoundTesting1()
			throws MobileNotFoundException, DuplicateIdException, InsufficientBalanceException {
		service.createCustomer("Nonu", "9908182359", new BigDecimal(1200));
		service.withdraw("8979225022", new BigDecimal(1700));
	}


	/************************************
	 * Test case for deposit()
	 ************************************/
	
	@Test
	public void depositTesting() throws DuplicateIdException, MobileNotFoundException {
		service.createCustomer("Nonu", "9808182349", new BigDecimal(2000));
		Customer cust = service.deposit("9808182349", new BigDecimal(2500));
		Customer customer = new Customer();
		Wallet wallet = new Wallet();
		Transaction transaction = new Transaction();
		transaction.setBalance(new BigDecimal(4500));
		transaction.setTransactionType("Credit");
		transaction.setAmount(new BigDecimal(2500));
		transaction.setMobile("9808182349");
		customer.setName("Nonu");
		customer.setPhone("9808182349");
		customer.setWallet(wallet);
		customer.setListOfTransaction(cust.getListOfTransaction());
		wallet.setBalance(new BigDecimal(4500));
		assertEquals(customer, cust);
	}
	
	
	/************************************
	 * Test case for deposit()
	 ************************************/
	
	@Test(expected = MobileNotFoundException.class)
	public void mobileNotFoundTesting2()
			throws MobileNotFoundException, DuplicateIdException, InsufficientBalanceException {
		service.createCustomer("Nonu", "9808882359", new BigDecimal(1200));
		service.deposit("8979225022", new BigDecimal(1700));
	}
	

	/************************************
	 * Test case for transfer()
	 ************************************/
	
	@Test
	public void transferTesting() throws DuplicateIdException, MobileNotFoundException, InsufficientBalanceException {
		Customer customer1 = service.createCustomer("Shubham", "8787965489", new BigDecimal(1200));
		Customer customer2 = service.createCustomer("Yanshu", "8979225022", new BigDecimal(1500));
		Customer customer[] = service.transfer("8787965489", "8979225022", new BigDecimal(1000));
		Customer customer3 = new Customer();
		Wallet wallet1 = new Wallet();
		Transaction transaction1 = new Transaction();
		transaction1.setBalance(new BigDecimal(200));
		transaction1.setTransactionType("Credit");
		transaction1.setAmount(new BigDecimal(1000));
		transaction1.setMobile("8787965489");
		customer3.setName("Shubham");
		customer3.setPhone("8787965489");
		customer3.setWallet(wallet1);
		customer3.setListOfTransaction(customer1.getListOfTransaction());
		wallet1.setBalance(new BigDecimal(200));
		Customer customer4 = new Customer();
		Wallet wallet2 = new Wallet();
		Transaction transaction2 = new Transaction();
		transaction2.setBalance(new BigDecimal(2500));
		transaction2.setTransactionType("Credit");
		transaction2.setAmount(new BigDecimal(1000));
		transaction2.setMobile("8787965489");
		customer4.setName("Yanshu");
		customer4.setPhone("8979225022");
		customer4.setWallet(wallet2);
		customer4.setListOfTransaction(customer2.getListOfTransaction());
		wallet2.setBalance(new BigDecimal(2500));
		assertEquals(customer3, customer[0]);
		assertEquals(customer4, customer[1]);
	}


	/************************************
	 * Test case for transfer()
	 ************************************/
	
	@Test(expected = InsufficientBalanceException.class)
	public void insufficientBalanceTesting2()
			throws DuplicateIdException, MobileNotFoundException, InsufficientBalanceException {
		service.createCustomer("Nonu", "8908182359", new BigDecimal(1200));
		service.createCustomer("Yanshu", "8079225022", new BigDecimal(1500));
		service.transfer("8908182359", "8079225022", new BigDecimal(5000));
	}

	
	/************************************
	 * Test case for transfer()
	 ************************************/
	
	@Test(expected = MobileNotFoundException.class)
	public void mobileNotFoundTesting4()
			throws DuplicateIdException, MobileNotFoundException, InsufficientBalanceException {
		service.createCustomer("Nonu", "9804582353", new BigDecimal(1200));
		service.createCustomer("Yanshu", "8974725022", new BigDecimal(1500));
		service.transfer("9804582353", "8979224022", new BigDecimal(5000));
	}

	
	/************************************
	 * Test case for transfer()
	 ************************************/
	
	@Test(expected = MobileNotFoundException.class)
	public void mobileNotFoundTesting5()
			throws DuplicateIdException, MobileNotFoundException, InsufficientBalanceException {
		service.createCustomer("Nonu", "9808178353", new BigDecimal(1200));
		service.createCustomer("Yanshu", "8980225022", new BigDecimal(1500));
		service.transfer("9808182373", "8980225022", new BigDecimal(5000));
	}
}
