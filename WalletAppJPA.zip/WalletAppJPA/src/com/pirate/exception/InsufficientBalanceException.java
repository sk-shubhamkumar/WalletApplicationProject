package com.pirate.exception;

public class InsufficientBalanceException extends Exception {

	@Override
	public String toString() {
		return "Insufficient Balance.";
	}

}
