package com.pirate.service;

import java.math.BigDecimal;
import java.util.List;

import com.pirate.bean.Customer;
import com.pirate.bean.Transaction;
import com.pirate.exception.DuplicateIdException;
import com.pirate.exception.InsufficientBalanceException;
import com.pirate.exception.MobileNotFoundException;

public interface IWalletService {

	Customer createCustomer(String name, String phone, BigDecimal balance) throws DuplicateIdException;

	Customer showBalance(String phone) throws MobileNotFoundException;

	Customer deposit(String mobile2, BigDecimal balance1) throws MobileNotFoundException;

	Customer withdraw(String mobile3, BigDecimal balance2) throws MobileNotFoundException, InsufficientBalanceException;

	Customer[] transfer(String mobile4, String mobile5, BigDecimal balance3)
			throws MobileNotFoundException, InsufficientBalanceException;

	List<Transaction> showLastTransactions(String mobile6, int noOfTransaction) throws MobileNotFoundException;

}