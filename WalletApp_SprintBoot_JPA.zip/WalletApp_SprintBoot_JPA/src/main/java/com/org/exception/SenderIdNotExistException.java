package com.org.exception;

public class SenderIdNotExistException extends IdNotExistException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}