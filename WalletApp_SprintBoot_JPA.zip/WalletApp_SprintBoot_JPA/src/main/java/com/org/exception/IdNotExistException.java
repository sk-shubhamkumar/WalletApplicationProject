package com.org.exception;

public class IdNotExistException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}