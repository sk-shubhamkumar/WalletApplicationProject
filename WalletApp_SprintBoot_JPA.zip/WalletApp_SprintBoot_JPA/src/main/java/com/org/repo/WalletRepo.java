package com.org.repo;

import com.org.bean.Customer;

public interface WalletRepo {

	boolean save(Customer customer);

	Customer search(String mobileNumber);

	boolean closeConnection();

	boolean updateAccount(Customer customer);

	boolean updateAccount(Customer sender, Customer receiver);

}